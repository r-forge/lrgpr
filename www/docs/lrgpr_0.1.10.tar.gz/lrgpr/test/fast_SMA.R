


# GEH February 5, 2014

n = 30
p = 5

x = matrix(rnorm(n), nrow=n)
y = matrix(rnorm(n), nrow=n)
W = matrix(rnorm(n*p), n,p)


t(x) %*% W %*% solve(crossprod(W)) %*% t(W) %*% x

dcmp = svd(W)

P = W %*% dcmp$v %*% diag(1/dcmp$d)

(t(x) %*% P) %*% t(t(x) %*% P)


Px = crossprod(P, x)
Py = crossprod(P, y)


beta = solve( crossprod(x) - crossprod(Px) ) %*% ( crossprod(x,y) - crossprod(Px, Py))

beta 

coef(lm( y ~ x + W-1))[1]

lm( y ~ x + W-1)$residuals[1:5]

Z = W %*% solve(crossprod(W)) %*% t(W) 
r = y - x %*% beta - Z %*% y + Z %*% x %*% beta

r[1:5]


Zy = W %*% solve(crossprod(W)) %*% (t(W) %*%y)
Zx = W %*% solve(crossprod(W)) %*% (t(W) %*%x)
r = y - x %*% beta - Zy + Zx %*% beta

r[1:5]


r = y - x %*% beta - P %*% Py + (P %*% Px) %*% beta

r[1:5]



x = 0:5
c1 = 1

par(mfrow=c(1,2))
plot(x, (x+c1)^3, col="red", ylim=c(0, max((x+c1)^3)), main="Time comparison", pch=20)

points(x, c1^2*x, col="blue", pch=20)

y = (x+c1)^3 / (c1^2*x)
plot(x, y, main="Speedup", ylim=c(0, max(y[is.finite(y)])), pch=20)


# Time simulations
###################

# The speed up was only ~2x wich is about 10x lower than expected
# Could this be due to R overhead?



library(compiler)

method1 = cmpfun(function(){
	Z = cbind(x,W)
	beta = solve(crossprod(Z)) %*% crossprod(Z,y)
	r = y - Z%*%beta
	apply(r, 2, function(a){sum(a^2)})
})

method2 = cmpfun(function(){	

	#Px = crossprod(P, x)

	#beta = solve( crossprod(x) - crossprod(Px) ) %*% ( crossprod(x,y) - crossprod(Px, Py))
	#beta = chol2inv(chol( crossprod(x) - crossprod(Px) )) %*% ( crossprod(x,y) - crossprod(Px, Py))
	#beta = crossprod(chol2inv(chol( crossprod(x) - crossprod(Px) )), crossprod(x,y) - crossprod(Px, Py))

	#r = y_PPy - x %*% beta  + (P %*% Px) %*% beta

	#apply(r, 2, function(a){sum(a^2)})
	#sum(r^2) 

	#crossprod(y_PPy) + crossprod(x%*%beta) + crossprod((P %*% Px) %*% beta) - 2 * crossprod(x%*%beta, (P %*% Px) %*% beta) - 2*crossprod(y_PPy, x%*%beta) - 2*crossprod(y_PPy, (P %*% Px) %*% beta)

	#cp_y_PPy + crossprod(beta, crossprod(x)) %*% beta - crossprod(beta, crossprod(Px)) %*% beta - 2*crossprod(y, x) %*% beta + 2*crossprod(Py, Px) %*% beta


	Px = crossprod(P, x)

	#beta = crossprod(chol2inv(chol( crossprod(x) - crossprod(Px) )), crossprod(x,y) - crossprod(Px, Py))

	#cp_y_PPy + crossprod(beta, crossprod(x)) %*% beta - crossprod(beta, crossprod(Px)) %*% beta - 2*crossprod(y, x) %*% beta + 2*crossprod(Py, Px) %*% beta

	cp_x = crossprod(x)
	cp_Px = crossprod(Px)
	cp_yx = crossprod(y,x)
	cp_PyPx = crossprod(Py,Px)

	beta = tcrossprod(chol2inv(chol( cp_x - cp_Px)), cp_yx - cp_PyPx)

	SSE = cp_y_PPy + crossprod(beta, cp_x) %*% beta - crossprod(beta, cp_Px) %*% beta - 2*cp_yx %*% beta + 2*cp_PyPx %*% beta



	C = chol2inv(chol( cp_x - cp_Px))
	crossprod(beta[1], cp_x - cp_Px) %*% beta[1]

	SSE / (nrow(y) - ncol(W) -1)

	fit = lm( y ~ x + W -1)

	crossprod(beta[1], 1/vcov(fit)[1,1]) %*% beta[1]

	A = cbind(x, W)

	solve(crossprod(A)) %*% t(A) %*% y
	
	#vcov(fit)[1:5, 1:5]	
	C = solve(crossprod(A)) * (SSE[1,1] / (nrow(y) - ncol(A)))

	sig_sq = nrow(y) - ncol(A)
	C = crossprod(A)

	crossprod(beta, solve(C)) %*% beta

	solve(C)[1,1]*sqrt(sig_sq)


	crossprod(beta, solve(C)[1,1]*sqrt(sig_sq)) %*% beta

	crossprod(beta, solve(C[1,1])*sqrt(sig_sq)) %*% beta


	sig_sq = SSE[1,1] / (nrow(y) - ncol(A))

	S = solve(crossprod(A)) * sig_sq

	stat = crossprod(beta[1], solve(S[1,1])) %*% beta[1]

	pchisq(stat, 1, lower.tail=F)


	S = solve(crossprod(A)) * sig_sq

	G = matrix(NA, nrow=ncol(x)+ncol(W), ncol=ncol(x)+ncol(W))
	G[1:ncol(x), 1:ncol(x)] = crossprod(x)
	G[1:ncol(x), (ncol(x)+1):ncol(G)] = crossprod(W, x)
	G[(ncol(x)+1):ncol(G), 1:ncol(x)] = t(G[1:ncol(x), (ncol(x)+1):ncol(G)] )
	G[(ncol(x)+1):ncol(G),(ncol(x)+1):ncol(G)] = crossprod(W)

	H = solve(G) 

	stat = crossprod(beta[1], solve(H[1,1])/sig_sq ) %*% beta[1]

	pchisq(stat, 1, lower.tail=F)



})


method2 = cmpfun(function(){
	
	Px = crossprod(P, x)

	cp_x = crossprod(x)
	cp_Px = crossprod(Px)
	cp_yx = crossprod(y,x)
	cp_PyPx = crossprod(Py,Px)

	beta = tcrossprod(chol2inv(chol( cp_x - cp_Px)), cp_yx - cp_PyPx)

	SSE = cp_y_PPy + crossprod(beta, cp_x) %*% beta - crossprod(beta, cp_Px) %*% beta - 2*cp_yx %*% beta + 2*cp_PyPx %*% beta
})


method3 = cmpfun(function(){
	
	Px = crossprod(P, x)

	cp_x = crossprod(x)
	cp_Px = crossprod(Px)
	cp_yx = crossprod(y,x)
	cp_PyPx = crossprod(Py,Px)

	beta = tcrossprod(chol2inv(chol( cp_x - cp_Px)), cp_yx - cp_PyPx)

	#r = y - P %*% crossprod(P, y) - x %*% beta + P %*% crossprod(P, x) %*% beta

	#SSE = crossprod(r)
})

system.time(replicate(5000, method3()))[3]

set.seed(1)
n = 5000

c1 = 1
p_array = (1:7)^2
results = matrix(0,length(p_array),2)

for( i in 1:length(p_array) ){

	x = matrix(rnorm(n*c1), nrow=n, ncol=c1)
	y = matrix(rnorm(n*2), nrow=n, ncol=2)
	W = matrix(rnorm(n*p_array[i]), n, p_array[i])

	dcmp = svd(W)

	P = W %*% dcmp$v %*% diag(1/dcmp$d, p_array[i])

	Py = crossprod(P, y)
	PPy = P %*% Py
	y_PPy = y - PPy
	cp_y_PPy = crossprod(y_PPy)
	cp_y_PPy = crossprod(y) - crossprod(Py) 


	results[i,1] = system.time(replicate(5000, method1()))[3]

	results[i,2] = system.time(replicate(5000, method2()))[3]
}


par(mfrow=c(1,2))

plot(p_array, results[,1], col="red", ylim=range(results), ylab="Time (s)", xlab="# of covariates")
points(p_array, results[,2], col="blue")

fit1 = lm( results[,2] ~ p_array)
lines( p_array, predict(fit1) )

fit2 = lm(results[,1] ~ p_array + I(p_array^2) )

lines( p_array, predict(fit2) )

plot(p_array, results[,1] / results[,2], xlab="# of covariates", ylab="Speed improvement")

x = 1:max(p_array)
M = data.frame(p_array=x)

lines(x, predict(fit2, M) / predict(fit1, M) )


cbind(p_array, results)


q()
R
library(lrgpr)

set.seed(1)
n = 5000
c1 = 1

x = matrix(rnorm(n*c1), nrow=n, ncol=c1)
y = matrix(rnorm(n*2), nrow=n, ncol=2)
W = matrix(rnorm(n*4), n, 4)

# Fit model for all markers
glmApply2( y ~ SNP + W-1, features=x, terms=c(3,4), nthreads=1)




glmApply( y ~ SNP + W-1, features=x, terms=c(3,4), nthreads=1)


# WTCCC test
#############

q()
R
library(lrgpr)
disease = "CD"
X <- attach.big.matrix( paste(disease, ".binary_descr", sep=''))

FAM = read.tfam(paste(disease, ".fam", sep=''))

sex = FAM$sex
y = FAM$phenotype - 1

p1 = glmApply( y ~ sex + SNP, features=X, nthreads=16)$pValues



q()
R
library(lrgpr)
disease = "CD"
X <- attach.big.matrix( paste(disease, ".binary_descr", sep=''))

FAM = read.tfam(paste(disease, ".fam", sep=''))

sex = FAM$sex
y = FAM$phenotype - 1


k = 100
M= matrix(rnorm(length(y)*k), ncol=k)

p1 = glmApply( y ~ sex + SNP + M, features=X, nthreads=16)$pValues
p2 = glmApply2( y ~ sex + SNP + M, features=X, nthreads=16)$pValues



