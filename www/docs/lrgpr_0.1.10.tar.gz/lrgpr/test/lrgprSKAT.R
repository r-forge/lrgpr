
library(SKAT)
library(biomaRt)

source("/home/ghoffman/workspace/repos/lrgpr/pkg/lrgpr/test/map_functions.R")

#' Convert LRGPR fit to SKAT object
#'
#' @seealso SKAT_NULL_Model, lrgpr
#' @export
lrgprToSKAT = function(fit){
	skat_obj = list()
	skat_obj$res = fit$residuals
	skat_obj$out_type = "C"
	skat_obj$id_include = 1:length(fit$residuals)
	skat_obj$X1 = fit$x
	skat_obj$n.Resampling = 0
	skat_obj$s2 = fit$sigSq_e
	skat_obj$type.Resampling = "bootstrap"
	skat_obj$n.all = length(fit$residuals)
	class(skat_obj) = "SKAT_NULL_Model"

	return(skat_obj)
}

#' SKAT using LRGPR to fit null model
#'
#' Test for association between a set of SNPs and a phenotype, with correction for population structure and polygentic architecture using a linear mixed model (i.e. `lrgpr') 
#'
#' @param fit fit of null model produced by `lrgpr'
#' @param Z set of SNPs being tested
#' @param W_til markers used to construct decomp that should now be removed from costruction of decomp.  This is the proximal contamination term of Listgarten, et al. (2012)
#' @param kernel kernel function for `SKAT'
#' @param weights weights for `SKAT'
#' @param method method for `SKAT'
#' @param r.corr r.corr for `SKAT'
#' @param is_dosage  for `SKAT'
#'
#' @seealso lrgpr, SKAT
#'
#' @export
lrgprSKAT = function( fit, Z, W_til=NULL, kernel = "linear.weighted", weights=NULL, method="davies", r.corr=0, is_dosage=FALSE){

	if( ! ("lrgpr" %in% class(fit)) ){
		stop("fit must be of class lrgpr")
	}

	if( is.null(weights) ){
		kernel = "linear"
	}

	# if the set of markers to be excluded from the random effect
	#	 is not NULL, then re-evaluate the lrgpr
	# 
	if( !is.null(W_til) ){
		# do not add additional mean term
		fit = lrgpr( fit$y ~ -1 + fit$x, dcmp, W_til=W_til)
	}

	pValue = SKAT(Z, lrgprToSKAT(fit), kernel=kernel, weights=weights, method=method, r.corr=r.corr, is_dosage=is_dosage, is_check_genotype=FALSE)$p.value

	return( pValue )
}


get_genes = function(){

	ensembl = useMart("ensembl", "hsapiens_gene_ensembl")

	attributes=c("ensembl_gene_id", "chromosome_name", "start_position", "end_position", "external_gene_id" )
	data = getBM(attributes, filters = "chromosome_name", values = c(1:22,"X"), mart = ensembl)

	return(data)
}

SKATApply = function( obj, data, X, up, down=up){

	pValues = rep(NA, nrow(data))
	names(pValues) = data$external_gene_id

	for( i in 1:nrow(data) ){

		cat("\r", i, "/", nrow(data), "           ")

		chrom = data$chromosome_name[i]
		start = data$start_position[i]
		end = data$end_position[i]

		idx = get_markers_in_interval( chrom, start, end, up, down, MAP[,1], MAP[,4])

		if( length(idx) > 0){
			# get markers in the set
			Z = set_missing_to_mean(X[,idx,drop=F])

			pValues[i] = SKAT(Z, obj, is_dosage=TRUE)$p.value
		}else{
			pValues[i] = NA
		}
	}

	return(pValues)
}



if(0){

disease = "CD"
MAP = read.table(paste(disease, ".map2", sep=''))




########
# SKAT #
########

obj <- SKAT_Null_Model(y ~ sex, out_type="D")

pValues = 1:nrow(data)
names(pValues) = data$external_gene_id

for( i in 1:nrow(data) ){

	cat("\r", i, "/", nrow(data), "           ")

	chrom = data$chromosome_name[i]
	start = data$start_position[i]
	end = data$end_position[i]

	idx = get_markers_for_gene( chrom, start, end, 50000, 50000, MAP[,1], MAP[,4])

	# get markers in the set
	Z = set_missing_to_mean(X[,idx,drop=F])

	if( length(idx) > 0){
		pValues[i] = SKAT(Z, obj, is_dosage=TRUE)$p.value
	}else{
		pValues[i] = NA
	}
}

#############
# lrgprSKAT #
#############

n = 2000
p = 300
dcmp = svd(matrix(rnorm(n*p), nrow=n))

fit = lrgpr( y ~ sex, dcmp)

pValues = 1:nrow(data)
names(pValues) = data$external_gene_id

for( i in 1:nrow(data) ){

	cat("\r", i, "/", nrow(data), "           ")

	chrom = data$chromosome_name[i]
	start = data$start_position[i]
	end = data$end_position[i]

	idx = get_markers_in_interval( chrom, start, end, 50000, 50000, MAP[,1], MAP[,4])

	if( length(idx) > 0){
		# get markers in the set
		Z = set_missing_to_mean(X[,idx,drop=F])

		# get proximal markers to exclude from dcmp
		W_til = NULL

		pValues[i] = lrgprSKAT( fit, Z, W_til=W_til, is_dosage=TRUE)$p.value
	}else{
		pValues[i] = NA
	}
}


# w_til_idx = get_markers_in_window( chrom, start, end, map, distance, dcmp_features)3
# lrgprSKAT( fit, Z, W_til=X[,idx])

}