



q()
R

set.seed(1)
library(plink)

X = read.tped("test_500_10000.tped")

y = as.matrix(read.table("test.tfam")[,6])
mu = rep(1, length(y))

K = crossprod(matrix(rnorm(500*1000), 500,500))
decomp = eigen(K, symmetric=TRUE)


#decomp$values = rep(1, length(decomp$values))

library(lrgpr)

y = as.vector(X[,1:10] %*% rnorm(10))

#fit = penreglmm( y, X[,1:2], as.matrix(mu), lambda=1, penalty="LASSO", family="gaussian", dfmax=1000, standardize=FALSE, moreDense=FALSE, decomp=decomp)

evalues = decomp$values

lambda = 1

Xu = crossprod(decomp$vectors, X[,1:2])
Xu_cov = crossprod(decomp$vectors, mu)
Yu = crossprod(decomp$vectors, y)

soft = function(beta, lambda){

	if( beta > lambda){
		return( beta - lambda)
	}else if( -beta > lambda){
		return( beta + lambda)
	}else{
		return(0)
	}
}



delta_array = exp(seq(-10, 10, length.out=100))

maximize_delta = function(fxn=ll){
	log_L = c()
	delta_values = c()
	for(i in 2:length(delta_array) ){	

		fit = optimize( fxn, interval=c(delta_array[i-1], delta_array[i]), maximum=TRUE)
		log_L[i-1] = fit$objective
		delta_values[i-1] = fit$maximum
	}
	i = which.max(log_L)
	return(list(delta=delta_values[i], log_L = log_L[i]))
}

ll_reest = function(delta){
	w = 1/(evalues+delta)

	beta = solve( (t(Xu_cov)*w) %*% Xu_cov ) %*% (t(Xu_cov)*w) %*% (v + Xu_cov %*% beta )
	v = (v - Xu_cov%*%(beta-beta_prev))
	sig_g = sum(v^2*w)/n
	-0.5*(n*log(2*pi*sig_g) + sum(log(evalues+delta)) + n) - lambda*sum(abs(beta_lasso))
}



ll = function(delta){
	w = 1/(evalues+delta)
	sig_g = sum(v^2*w)/n
	-0.5*(n*log(2*pi*sig_g) + sum(log(evalues+delta)) + n) - lambda*sum(abs(beta_lasso))
}

n = length(y)


Xu = crossprod(decomp$vectors, X[,1:200])

lambda = 95.53772
beta_lasso = rep(0, ncol(Xu))
beta_lasso_prev = beta_lasso
beta = rep(0, ncol(Xu_cov))
beta_prev = beta
log_L = c()

v = Yu
fit = maximize_delta(ll_reest)
w = 1/(evalues+fit$delta)
beta = solve( (t(Xu_cov)*w) %*% Xu_cov ) %*% (t(Xu_cov)*w) %*% (Yu - Xu %*% beta_lasso ) #(v + Xu_cov %*% beta )
v = Yu  - Xu_cov%*%beta - Xu%*%beta_lasso

beta_prev = beta
max_d = 0

#delta = 1e4

for( k in 1:30){	

	if(k == 1) cat("dbeta\tdbeta_lasso\tdelta\tsig_g\tlog_L\tdlog_L\n", sep='') 
	fit = maximize_delta(ll_reest)
	delta = fit$delta	
	#delta = 1
	w = 1/(evalues+delta)

	beta_prev = beta
	beta = solve( (t(Xu_cov)*w) %*% Xu_cov ) %*% (t(Xu_cov)*w) %*% (Yu - Xu %*% beta_lasso )
	#beta = solve( (t(Xu_cov)*w) %*% Xu_cov ) %*% (t(Xu_cov)*w) %*% (v + Xu_cov %*% beta )

	#cat(sum((beta-beta_prev)^2), "\t")

	v = Yu  - Xu_cov%*%beta - Xu%*%beta_lasso
	#v = (v - Xu_cov%*%(beta-beta_prev))

	log_L_prev = ll(delta) 	
	sig_g = sum(v^2*w)/n  
	
	for(j in 1:ncol(Xu) ){	

		s = ((t(Xu[,j]) * w)%*%Xu[,j])[1]

		d = beta_lasso[j] * s + Xu[,j] %*% (v*w)
		beta_lasso_prev[j] = beta_lasso[j]
		beta_lasso[j] = soft( d, sig_g*lambda)/s
		max_d = max(max_d, abs(d))
		#v = (v - Xu[,j]*(beta_lasso[j]-beta_lasso_prev[j]))
		v = Yu - Xu%*%beta_lasso - Xu_cov%*%beta
	}
	cat( sum((beta_lasso-beta_lasso_prev)^2), "\t", delta, "\t", sig_g, "\t", sep='')

	log_L[k] = ll(delta) 
	if( k == 1) cat(log_L[k], "\n")
	else cat(log_L[k], " ", log_L[k]-log_L[k-1], "\n")

	if( sum((beta_lasso-beta_lasso_prev)^2) < 1e-7) break
}




length(which(beta_lasso!=0))















# OLD BELOW !!!!


# solve( (t(Xu) /(evalues + delta)) %*% Xu  ) %*% (t(Xu) / (evalues + delta)) %*% Yu 
# (crossprod(v, diag(w)) %*% Xu[,j]) / (crossprod(Xu[,j], diag(w)) %*% Xu[,j])


ll = function(delta){

	beta = solve( (t(Xu_cov) /(evalues + delta)) %*% Xu_cov  ) %*% (t(Xu_cov) / (evalues + delta)) %*% Yu 

	n = length(y)

	r = Yu - Xu_cov %*% beta - Xu %*% beta_lasso

	sig_g = sum(r^2/(evalues+delta))/n

	-0.5*(n*log(2*pi*sig_g) + sum(log(evalues+delta)) + sum(r^2/(evalues+delta))/sig_g) - lambda*sum(abs(beta_lasso))
}

ll_lasso = function(){

	n = length(y)

	r = Yu - Xu_cov %*% beta - Xu %*% beta_lasso

	sig_g = sum(r^2/(evalues+delta))/n

	-0.5*(n*log(2*pi*sig_g) + sum(log(evalues+delta)) + sum(r^2/(evalues+delta))/sig_g) - lambda*sum(abs(beta_lasso))
}


delta_array = exp(seq(-10, 10, length.out=100))

beta_lasso = rep(0, ncol(Xu))

maximize_delta = function(){
	log_L = c()
	delta_values = c()
	for(i in 2:length(delta_array) ){	

		fit = optimize( ll, interval=c(delta_array[i-1], delta_array[i]), maximum=TRUE)
		log_L[i-1] = fit$objective
		delta_values[i-1] = fit$maximum
	}
	i = which.max(log_L)
	return(list(delta=delta_values[i], log_L = log_L[i]))
}

plot(log(delta_values), log_L)

delta =
delta

#lrgpr( y, X[,1:2], decomp)$delta
#lrgpr( y, X[,1:2], decomp)$coefficients






beta_lasso = rep(0, ncol(Xu))

	lambda = 0
	delta = 7021.37

	beta = solve( (t(Xu_cov) /(evalues + delta)) %*% Xu_cov  ) %*% (t(Xu_cov) / (evalues + delta)) %*% Yu 
	cat(ll(delta), "\n")
	v = Yu - Xu_cov %*% beta - Xu %*% beta_lasso 
	#cat(ll_lasso(), "\n")
	for(j in 1:ncol(Xu) ){
		sig_g = sum(v^2/(evalues+delta))/n
		w = 1/(evalues+delta)
	
		s = ((t(Xu[,j]) * w)%*%Xu[,j])[1]

		d = beta_lasso[j] * s + Xu[,j] %*% (v*w)
		
		beta_prev = beta_lasso[j]
		beta_lasso[j] = soft( d, sig_g*lambda)/s
		
		v = v - Xu[,j]*(beta_lasso[j]-beta_prev)
	}
	cat(ll(delta), "\n")
	#cat(ll_lasso(), "\n")

	beta_lasso

(Yu - Xu_cov %*% beta - Xu %*% beta_lasso )[1:3]

(v - Xu[,j] * beta_lasso[j])[1:3]




lambda = 10
beta_lasso = rep(0, ncol(Xu))
fit = maximize_delta()
delta = fit$delta

for( k in 1:10){
	
	cat(ll(delta), "\n")

	v = Yu - Xu_cov %*% beta - Xu %*% beta_lasso 
	for(j in 1:ncol(Xu) ){
		sig_g = sum(v^2/(evalues+delta))/n
		w = 1/(evalues+delta)

		s = ((t(Xu[,j]) * w)%*%Xu[,j])[1]

		d = beta_lasso[j] * s + Xu[,j] %*% (v*w)
		beta_prev = beta_lasso[j]
		beta_lasso[j] = soft( d, sig_g*lambda)/s

		v = v - Xu[,j]*(beta_lasso[j]-beta_prev)
	}

	fit = maximize_delta()
	delta = fit$delta
	cat(fit$log_L, "\n")
}
beta_lasso




# final working version??
ll = function(delta){

	#w = 1/(evalues+delta)
	#beta = solve( (t(Xu_cov)*w) %*% Xu_cov  ) %*% (t(Xu_cov)*w) %*% (Yu - Xu %*% beta_lasso )
	#beta_lasso = solve( (t(Xu) *w) %*% Xu ) %*% (t(Xu) * w) %*% (Yu - Xu_cov %*% beta )

	n = length(Yu)

	r = Yu - Xu_cov %*% beta - Xu %*% beta_lasso

	sig_g = sum(r^2/(evalues+delta))/n

	-0.5*(n*log(2*pi*sig_g) + sum(log(evalues+delta)) + sum(r^2/(evalues+delta))/sig_g) - 0.5*lambda*sig_g*sum(abs(beta_lasso))
}

delta_array = exp(seq(-10, 10, length.out=100))

beta_lasso = rep(10, ncol(Xu))

maximize_delta = function(){
	log_L = c()
	delta_values = c()
	for(i in 2:length(delta_array) ){	

		fit = optimize( ll, interval=c(delta_array[i-1], delta_array[i]), maximum=TRUE)
		log_L[i-1] = fit$objective
		delta_values[i-1] = fit$maximum
	}
	i = which.max(log_L)
	return(list(delta=delta_values[i], log_L = log_L[i]))
}

n = length(y)


Xu = crossprod(decomp$vectors, X[,1:3])

lambda = 0
beta_lasso = rep(1, ncol(Xu))
beta_prev = beta_lasso
log_L = c()



for( k in 1:200){

	fit = maximize_delta()
	delta = fit$delta	
	#delta = 1
	w = 1/(evalues+delta)

	beta = solve( (t(Xu_cov)/w) %*% Xu_cov  ) %*% (t(Xu_cov)/w) %*% (Yu - Xu %*% beta_lasso )
	v = Yu - Xu%*%beta_lasso - Xu_cov%*%beta
	sig_g = sum(v^2/w)/n
	#beta_lasso = solve( (t(Xu) /(evalues + delta)) %*% Xu ) %*% (t(Xu) / (evalues + delta)) %*% (Yu - Xu_cov %*% beta )

	for(j in 1:ncol(Xu) ){	

		s = ((t(Xu[,j]) * w)%*%Xu[,j])[1]

		d = beta_lasso[j] * s + Xu[,j] %*% (v*w)
		beta_prev[j] = beta_lasso[j]
		beta_lasso[j] = soft( d, sig_g*lambda)/s

		#v = (v - Xu[,j]*(beta_lasso[j]-beta_prev[j]))
		v = Yu - Xu%*%beta_lasso - Xu_cov%*%beta
	}
	cat( sum((beta_lasso-beta_prev)^2), " ", delta, " ")


	log_L[k] = ll(delta) 
	if( k == 1) cat(log_L[k], "\n")
	else cat(log_L[k], " ", log_L[k]-log_L[k-1], "\n")

	if( sum((beta_lasso-beta_prev)^2) < 1e-6) break
}
beta_lasso









