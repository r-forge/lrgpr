




q()
R

# Conduct full rank analysis like EMMA/EMMAX/GEMMA 
##################################################

# load package
library(lrgpr)
source("/data/workspace/lrgpr/test/emma_FaST-LMM.R")


# load genotypes from plink TPED format
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep='') )$X

# load phenotype from plink TFAM format
fam = read.tfam( paste( .libPaths(), "/lrgpr/data/test.tfam", sep='') )

# load genetic relationship matrix
K = as.matrix(read.table( paste( .libPaths(), "/lrgpr/data/K.txt", sep='') ))

# Compute principal components of genetic relationship matrix
dcmp = svd(X)

rank = 6

decomp = list()
decomp$vectors = dcmp$u[,1:rank]
decomp$values = dcmp$d[1:rank]^2


form =  cbind( fam$sex, X[,1])

# Fit model
fit = lrgpr( fam$phenotype ~ form -1, decomp)

# View model fit in standard R format



fastfit = fastlmm( fam$phenotype, form , decomp=decomp, version = "lowrank", rank=rank)

fit$logLik
fastfit$ML

fit$delta
fastfit$delta

coef(fit)
c(fastfit$beta)



##########################################################
# Show that FaST-LMM with new svd is same as using W_til #
##########################################################

source("/data/workspace/lrgpr/test/emma_FaST-LMM.R")

# Simulate data
n = 500
p = 5000
X = matrix(rnorm(n*p), n, p)

Y = X[,100:109] %*%  rnorm(10)

# exclude these markers
rem = 10:12

# Craete low rank W
W = X[,100:160]

rank = ncol(W)

W_til = W[,rem]

# full SVD
dcmp = svd(W)

decomp = list()
decomp$vectors = dcmp$u[,1:rank]
decomp$values = dcmp$d[1:rank]^2

# SVD omitting makers in rem
dcmp_sub = svd(W[,-rem])
decomp_sub = list()
decomp_sub$vectors = dcmp_sub$u[,1:length(dcmp_sub$d)]
decomp_sub$values = dcmp_sub$d[1:length(dcmp_sub$d)]^2

form = X[,1]

#  Use full SVD and specify W_til
rank = length(decomp$values)
fastfit3 = fastlmm3( Y, form, decomp, rank=rank, W_til=W_til)

rank = length(decomp$values)
fastfit = fastlmm2( Y, form, decomp, rank=rank, W_til=W_til)

fastfit3$ML
fastfit$ML

fastfit3$delta
fastfit$delta

c(fastfit3$beta)
c(fastfit$beta)

fastfit3$vg
fastfit$vg


# Use new SVD
rank = length(decomp_sub$values)
fit_sub = fastlmm2( Y, form, decomp_sub, rank=rank)

# Results are the same

fit_sub$ML
fastfit$ML

fit_sub$delta
fastfit$delta

c(fit_sub$beta)
c(fastfit$beta)

fit_sub$vg
fastfit$vg


fit_sub$pValues
fastfit$pValues



X = cbind(1, form)






##################
# Test new lrgpr #
##################

q()
R

library(lrgpr)

# source("/data/workspace/lrgpr/test/emma_FaST-LMM.R")

# Simulate data
n = 500
p = 5000
X = matrix(rnorm(n*p), n, p)

Y = X[,100:109] %*%  rnorm(10)

# exclude these markers
rem = 10:12

# Craete low rank W
W = X[,100:160]

rank = ncol(W)

W_til = W[,rem]

# full SVD
dcmp = svd(W)

fit = lrgpr( Y ~ X[,1], dcmp, chisq=TRUE)


fit = lrgpr( Y ~ X[,1], dcmp, chisq=FALSE)




















#################################################
# Show that log-likelihood terms are equivalent #
#################################################

determinant(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n) - tcrossprod(W_til))

(sum( log(s + delta ) ) + (n-rank) * log(delta))  + determinant( I_c - Q_WW(delta))$modulus[1]



 Omega_rr(delta, beta) / n

t(Y - X %*% beta) %*% solve(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n) - tcrossprod(W_til)) %*% (Y - X %*% beta) / n








X = form

# Compare two svd directly

U = decomp$vectors[,1:rank]
s = rev(abs(decomp$values[1:rank]))
U = rev_matrix( U )
	


# original SVD
logDet = determinant(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n) - tcrossprod(W_til))$modulus[1]

-n/2*log(2*pi*sig_g) - 1/2 * logDet - n/2

# FaST-LMM

ld = sum( log(s + delta ) ) + (n-rank) * log(delta) + determinant( I_c - Q_WW(delta))$modulus[1]

-n/2 * log(2*pi*sig_g) - 1/2 * (sum( log(s + delta ) ) + (n-rank) * log(delta)) - n/2 - 1/2 * determinant( I_c - Q_WW(delta))$modulus[1]

U_sub = decomp_sub$vectors[,1:rank]
s_sub = rev(abs(decomp_sub$values[1:rank]))
U_sub = rev_matrix( U_sub )

# new SVD
logDet = determinant(tcrossprod(U_sub, diag(s_sub)) %*% t(U_sub) + diag(delta, n))$modulus[1]

-n/2*log(2*pi*sig_g) - 1/2 * logDet - n/2



A = tcrossprod(W) - tcrossprod(W_til) + diag(delta, n)

B = tcrossprod(W[,-rem]) + diag(delta, n )


determinant(A)$modulus[1]
determinant(B)$modulus[1]

sum(log(eigen(A)$values))
sum(log(eigen(B)$values))




t(W_til) %*% solve(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n) - tcrossprod(W_til)) %*% W_til


t(W_til) %*% solve(tcrossprod(U, diag(s)) %*% t(U) + diag(delta, n)) %*% W_til

crossprod(Wu, (1/(s+delta)) * Wu ) + (crossprod(W_til) - crossprod(Wu)) / delta








