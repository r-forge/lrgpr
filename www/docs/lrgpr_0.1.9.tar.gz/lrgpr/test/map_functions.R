
#' Get markers in an interval
#'
#' @param chr_j chromosome of query interval
#' @param start_j start bp of of query interval
#' @param end_j end of query interval
#' @param up bp upstream of start_j
#' @param down bp downstream of end_j
#' @param chrom chromosome entry for all available markers
#' @param location bp entry for all available markers
get_markers_in_interval = function( chr_j, start_j, end_j, up, down, chrom, location ){

	# get markers on the same chromosome
	idx = which( chrom == chr_j )
	
	# get markers within the window
	# ( start - up, start, end, end + down)
	idx_up = which( location[idx] >= c(start_j - up) )	
	idx_down = which( location[idx] <= c(end_j + down) )

	# intersectio of two lists give marker set
	set = intersect( idx[idx_up], idx[idx_down] )
	
	return( set )
}


get_markers_in_window = function( chr_j, loc_j, chrom, location, distance){

	# get markers on the same chromosome
	idx = which( chrom == chr_j )

	# get markers within the window 
	idx2 = which( abs(location[idx] - loc_j) <= distance )
	
	return( idx[idx2] )
}


get_exclude_markers = function(chr_j, loc_j, chrom, location, distance, dcmp_features){

	idx = get_markers_in_window( chr_j, loc_j, chrom[dcmp_features], location[dcmp_features], distance)

	dcmp_features[idx]
}

