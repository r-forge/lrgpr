

q()
R
suppressPackageStartupMessages(library(lrgpr))
file = paste( .libPaths(), "/lrgpr/data/test.tped", sep='')
markerNames = c("snp2 ", "snp7", "snp4", "snp343")
X_sub = read.tped( file, markerNames=markerNames)
X = read.tped( file )

j = match(colnames(X_sub), colnames(X))

diag(cor(X[,j], X_sub))



# SMA 
# select top k (1...1000) markers
# Read in best k markers
# CV based on each set
#	show cv plot
# Proximal contamination ???
# Random effects test using null


set.seed(1)

h_sq = .8

n = 200
p = 500
X = matrix(sample(0:2, n*p, replace=TRUE), nrow=n)

K = tcrossprod(X)
decomp = eigen(K, symmetric=TRUE)

eta =  decomp$vectors[,1:2] %*% rgamma(2, 2, 1) # as.numeric(sex)
error_var = (1-h_sq) / h_sq  * var(eta)
y = eta + rnorm(n, sd=sqrt(error_var))

i = order(cor(y, X)^2, decreasing=TRUE) 

fitnull = cv.lrgpr( y ~ 1, X[,i])

plot.cv.lrgpr(fitnull)






fitnull = cv.lrgpr( y ~ sex, X[,i], nthreads=8, n_confounders_used=2:5)

plot.cv.lrgpr(fitnull)



q()
R
suppressPackageStartupMessages(library(lrgpr))
 
# load genotypes from plink TPED format
X = read.tped( paste( .libPaths(), "/lrgpr/data/test.tped", sep='') )
 
# load phenotype from plink TFAM format
fam = read.tfam( paste( .libPaths(), "/lrgpr/data/test.tfam", sep='') )
 
# load genetic relationship matrix
K = as.matrix(read.table( paste( .libPaths(), "/lrgpr/data/K.txt", sep='') ))
 
# Compute principal components of genetic relationship matrix
decomp = eigen(K, symmetric=TRUE)
 
# Fit model
fit = lrgpr( fam$phenotype ~ fam$sex + X[,1], decomp)
 

pValues1 = lrgpr_batch( fam$phenotype ~ fam$sex + fam$sex:X[,j], loop="X[,j]", decomp, terms=c(3,4))



pValuesFast = glm_batch( fam$phenotype ~ fam$sex + fam$sex:X[,j], loop="X[,j]", terms=c(3,4), family=binomial())

library(aod)
pValuesSlow = c()
for(j in 1:ncol(X) ){
	fit = glm( fam$phenotype ~ fam$sex + fam$sex:X[,j] )

	pValuesSlow[j] = wald.test(vcov(fit), coef(fit), Terms=c(3,4))$result$chi2[3]
}


cor(pValuesFast, pValuesSlow)











y = sample(0:1, n, replace=TRUE)

fit = penreg( y, decomp$vectors, as.matrix(as.numeric(sex)), penalty="MCP", hp2=500, family="logistic" )

fitCVlasso = cv.penReg( y, decomp$vectors, as.matrix(as.numeric(sex)), family="binomial")

plot(fitCVlasso)



X_select = X[,1:10]

fitCV = cv.lrgpr( y ~ sex, K, rankArray=seq(0, 10, by=1), nfolds=10)
plot(fitCV)







#df <- lrgpr_univariateDF( y, model.matrix( y ~ sex), decomp)
dcmp2 = sort_principal_components( y ~ sex, decomp, method="lambda")
fit <- lrgpr_rankSearch( y ~ sex, decomp=dcmp2, maxRank=10)
dev.new()
plot(fit)




fit = lrgpr( y ~ sex, decomp=dcmp2, rank=10)



 X = cbind(1, sex)

obj = fit.i
X_test = X[i_train,,drop=FALSE]
K_test = K[i_train,i_train]







