
# GEH 
# March 4, 2014

library(compiler)
library(foreach)
library(doMC)
library(lrgpr)

registerDoMC(8)

# Empirical p-value using permutations
perm_p_value = cmpfun(function(y, s1, s2, k){

	n = length(y)

	# regression
	fit1 = lm(s1 ~ y)
	fit2 = lm(s2 ~ y)

	# simulate new values with same properties as s1, s2 using regression parameters
	# draw the covariance term from the null distribution
	null_values = foreach(i=1:n_reps, .combine=c) %do% {
		
		sigma1 = summary(fit1)$sigma
		sigma2 = summary(fit2)$sigma

		a1 = coef(fit1)[1] + coef(fit1)[2] * y + rnorm(n, 0, sigma1)
		a2 = coef(fit2)[1] + coef(fit2)[2] * y + rnorm(n, 0, sigma2)

		cov(a1[k], a2[k])
	}

	# compute the actual covariance
	stat = cov(s1[k], s2[k])

	# compare to null in a one-sided test
	sum(stat >= null_values) / length(null_values)
})


n_reps = 1000
n = length(y)
k = sum(y)

pValues = c()

pValues = foreach(i=1:200, .combine=c) %do% {
	y = rnorm(n)

	# lrgpr predictors
	s1  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)
	s2  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)

	perm_p_value(y, s1, s2, k) 
}

QQ_plot(pValues)

pValues1 = foreach(i=1:200, .combine=c) %dopar% {
	y = rnorm(n)

	# lrgpr predictors
	s1  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)
	s2  = runif(1, -.1,.1)*y + rnorm(n, 0, 2)
	
	coef(summary(lm( scale(s1[k]) ~ scale(s2[k])-1)))[1,4] 
}

plot(pValues, pValues1)





# Test difference between correlation in cases and controls

cor.p.value = function(y, s1, s2){

	k = which(y==1)

	r1 = cor(s1[k], s2[k])
	r2 = cor(s1[-k], s2[-k])

	n = length(k)
	se1 = sqrt((1 - r1^2)/(n-2))

	n = length(y) - length(k)
	se2 = sqrt((1 - r2^2)/(n-2))

	stat = (r1 - r2)^2 / (se1^2 + se2^2)

	pchisq(stat, 1, lower.tail=FALSE)
}

epistasisTestCor = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j]  = cor.p.value(y, M[,i], M[,j])
		}
	}	
	return(res)
}


epistasisTestCor2 = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j]  = cor.test(M[,i], M[,j])$p.value
		}
	}	
	return(res)
}

epistasisTestRegress = function(y, M){
	res = matrix(NA, ncol(M), ncol(M))

	for(i in 1:ncol(M)){
		for(j in (i+1):ncol(M)){
			if( j > ncol(M)) break
			res[i,j] = coef(summary(lm(y ~ M[,i]*M[,j])))[4,4]
		}
	}	
	return(res)
}


M = matrix(rnorm(length(y)*200), length(y), 200)

epiCor = epistasisTestCor( y, M)
epiReg = epistasisTestRegress( y, M)
