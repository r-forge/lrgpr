
sudo apt-get install libgsl0-dev
sudo apt-get install libboost-dev


http://www.gnu.org/software/gsl/




library(lrgpr)



# Plink files
tped_file = paste(system.file( package = 'lrgpr'), "/extdata/test.tped", sep="")
fam_File =  paste(system.file( package = 'lrgpr'), "/extdata/test.tfam", sep="")

# Convert TPED file to binary format
# Create a binary data file: test.binary
# 	and a binary file describing this data: test.binary_descr
convertToBinary(tped_file, "./test.binary", "TPED")

# attach data by reading the description file
X <- attach.big.matrix("/data/test_space/test.binary_descr")


FAM = read.tfam( fam_File )

y = FAM$phenotype
sex = FAM$sex

# Single marker analysis
pValues = glmApply( y ~ SNP + sex, features=X, terms=c(2))$pValues


pValues = glmApply( y ~ sex + SNP:X[,1], features=X, terms=c(3:5))$pValues


# Full rank linear mixed model
i = seq(1, ncol(X), by=100)

K = tcrossprod(scale(set_missing_to_mean(X[,i])))

dcmp = eigen(K, symmetric=TRUE)

fit = lrgpr( y ~ 1, dcmp)


# Linear mixed model analysis using markers selected by GCV
pValuesLMM_full = lrgprApply( y ~ SNP, features=X, decomp=dcmp, terms=c(2))


dcmp = svd(scale(set_missing_to_mean(X[,2:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp))$coefficients

dcmp = svd(scale(set_missing_to_mean(X[,1:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp, W_til=scale(X[,1])))$coefficients


dcmp = svd(scale(set_missing_to_mean(X[,1:5])))
summary(lrgpr(y ~ X[,1], decomp=dcmp, W_til=X[,1]))$coefficients






#################################################
# Learn the rank of random effect from the data #
#################################################

ord = order(pValues, decreasing=FALSE)

# Evaluate cross-validation for multiple rank values
fitcv = cv.lrgpr( y ~ sex, features=X, order=ord, nfolds=2 )

# Evaluate model criterion for multiple rank values using the degrees of freedom statistic
# Show Akaike Information Criterion (AIC), Bayesian Information Criterion (BIC) and generalized cross-validation (GCV)
fitcrit = criterion.lrgpr( y ~ sex, features=X, order=ord )

# Plot the cross-validation and model crition curves
par(mfrow=c(1,2))
plot.cv.lrgpr(fitcv)
plot.criterion.lrgpr(fitcrit)

#######################################################################
# Apply Linear Mixed Model analysis using the markers selected by GCV #
#######################################################################

# Perform singular value decomposition of the subset of markers
dcmp = svd(scale(set_missing_to_mean(X[,ord[1:fitcrit$best$GCV]])))

#############################################
# Evaluate the Linear Mixed Model by itself #
#############################################
fit = lrgpr(y ~ sex, dcmp)

par(mfrow=c(2,4))
plot(fit)
plot(lm(y ~ sex))

MAP = read.table("/data/test_space/MESA/MESA_Euro_nvtrg31c/MESA_complete.map")

# Linear mixed model analysis using markers selected by GCV
pValuesLMM = lrgprApply( y ~ SNP, features=X, decomp=dcmp, terms=c(2))






q()
R
library(lrgpr)



# Plink files
tped_file = paste(system.file( package = 'lrgpr'), "/extdata/test.tped", sep="")
fam_File =  paste(system.file( package = 'lrgpr'), "/extdata/test.tfam", sep="")

# attach data by reading the description file
X <- attach.big.matrix("/data/test_space/test.binary_descr")

FAM = read.tfam( fam_File )

y = FAM$phenotype
sex = FAM$sex


pValues = glmApply( y ~ sex + SNP:X[,1], features=X, terms=c(3:5), nthreads=1)$pValues


SNP = X[,1]


model.matrix.default(y ~ sex + SNP:X[,1])


q()
R

file.remove("lrgpr.aux"); Sweave('lrgpr.Rnw');  tools::texi2dvi('lrgpr.tex', pdf=T, clean=F); 

lrgprApply( y ~ sex + SNP*X[,1], features=X[,1:4], decomp=dcmp, terms=3:5)


# Prepare for SKAT

data(SKAT.example)
attach(SKAT.example)
#############################################################
# Compute the P-value of SKAT with the logistic Weight (par1=0.07, par2=150)
# Use logistic weight
obj<-SKAT_Null_Model(y.c ~ X, out_type="C")
weights<-Get_Logistic_Weights(Z, par1=0.07, par2=150)
SKAT(Z, obj, kernel = "linear.weighted", weights=weights)$p.value
# Weights function
MAF<-colMeans(Z)/2
plot(MAF,weights)

library(lrgpr)

n = 2000
p = 300
dcmp = svd(matrix(rnorm(n*p), nrow=n))


fit = lrgpr( y.c ~ X, dcmp)

lrgprToSKAT = function(fit){
	skat_obj = list()
	skat_obj$res = fit$residuals
	skat_obj$out_type = "C"
	skat_obj$id_include = 1:length(fit$residuals)
	skat_obj$X1 = fit$x
	skat_obj$n.Resampling = 0
	skat_obj$s2 = fit$sigSq_e
	skat_obj$type.Resampling = "bootstrap"
	skat_obj$n.all = length(fit$residuals)
	class(skat_obj) = "SKAT_NULL_Model"

	return(skat_obj)
}


Z = matrix(rnorm(n*500), nrow=n)



# Fit Null model

fit = lrgpr( y.c ~ X, dcmp)


lrgprSKAT = function( fit, Z, W_til=NULL, kernel = "linear.weighted", weights=NULL, method="davies", r.corr=0, is_dosage=FALSE){

	if( ! ("lrgpr" %in% class(fit)) ){
		stop("fit must be of class lrgpr")
	}

	if( is.null(weights) ){
		kernel = "linear"
	}

	# if the set of markers to be excluded from the random effect
	#	 is not NULL, then re-evaluate the lrgpr
	# 
	if( !is.null(W_til) ){
		# do not add additional mean term
		fit = lrgpr( fit$y ~ -1 + fit$x, dcmp, W_til=W_til)
	}

	pValue = SKAT(Z, lrgprToSKAT(fit), kernel=kernel, weights=weights, method=method, r.corr=r.corr, is_dosage=is_dosage, is_check_genotype=FALSE)$p.value

	return( pValue )
}


weights <- Get_Logistic_Weights(Z, par1=0.07, par2=150)
lrgprSKAT( fit, Z, weights=weights)

lrgprSKAT( fit, Z)

system.time(replicate(10, lrgprSKAT( fit, Z)))
system.time(replicate(10, lrgprSKAT( fit, Z, weights=weights)))


fit = lrgpr( y.c ~ X, dcmp)

lrgprSKAT( fit, Z, W_til=Z[,1:4])


# SKAT
######

# Fit linear model
obj<-SKAT_Null_Model(y.c ~ X, out_type="C")

# Score test on Z using on the residuals from the linear model
SKAT(Z, obj)$p.value

# SKAT + lrgpr
##############

# Fit linear mixed model
fit = lrgpr( y.c ~ X, dcmp)

# Score test on Z using on the residuals from the linear mixed model
lrgprSKAT( fit, Z, W_til=Z[,1:4])

# foreach gene
#	get marker indices, j, corresponding to gene
#	Z = X[,j]
#	idx = get_markers_in_window( j, map, distance, dcmp_features)
#	lrgprSKAT( fit, Z, W_til=X[,idx])


q()
R

library(lrgpr)

# Plink files
tped_file = paste(system.file( package = 'lrgpr'), "/extdata/test.tped", sep="")
fam_File =  paste(system.file( package = 'lrgpr'), "/extdata/test.tfam", sep="")

convertToBinary(tped_file, "./test.binary", "TPED")

# attach data by reading the description file
X <- attach.big.matrix("/data/test_space/test.binary_descr")

FAM = read.tfam( fam_File )

y = FAM$phenotype
sex = FAM$sex

# Full rank linear mixed model
i = seq(1, ncol(X), by=100)
K = tcrossprod(scale(set_missing_to_mean(X[,i])))
dcmp = eigen(K, symmetric=TRUE)

lrgpr( y ~ 1, dcmp)$df

fit = glmApply( y ~ SNP, X, progress=F)

X_sub = sub.big.matrix( X, firstRow = 1, lastRow=50)


fit2 = glmApply( y[1:10] ~ SNP, X, progress=F)




formula = y ~ 1
features = X
order = 1:ncol(X)
rank = 1:10




f = function(){
	fit = glm( a ~ 1)
	#fit = glmApply( a ~ SNP, X)
}

g = function(){
	a = rnorm(100)
	f()
}

g()

#' @param progress show progress bar 
, progress=TRUE

