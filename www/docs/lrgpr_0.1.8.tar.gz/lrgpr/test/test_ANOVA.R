

q()
R
library(lrgpr)

X = attach.big.matrix("test.binary_descr")

freq = getAlleleFreq(X)

freq2 = getAlleleFreq2(X)


cov(freq, freq2)
cov(freq2, freq2)



freq = getAlleleFreq(X[,])

freq2 = getAlleleFreq2(X[,], progress=FALSE)


cov(freq, freq2)
cov(freq2, freq2)





q()
R
library(lrgpr)

X = attach.big.matrix("IBD15_PCA.binary_descr")
 
freq = getAlleleFreq(X)
freq2 = getAlleleFreq2(X)


cov(freq, freq2)
cov(freq2, freq2)





q()
R
library(lrgpr)

set.seed(1)

X = attach.big.matrix("test.binary_descr")

y = rnorm(nrow(X))

p = glmApply( y ~ SNP, features=X, nthreads=1, progress=F)$pValues

p2 = glmApply2( y ~ SNP, features=X, nthreads=1, progress=F)$pValues

cor(p, p2, use="pairwise.complete")



# glmApply2()
# ANOVA test
# Generate data


q()
R
library(lrgpr)

set.seed(1)
n = 100
p = 500
X = matrix(sample(0:2, n*p, replace=TRUE), nrow=n)
y = rnorm(n)
sex = as.factor(sample(1:2, n, replace=TRUE))

# Fit model for all markers
pValues = glmApply( y ~ sex + SNP, features=X[,1])$pValues

pValues2 = glmApply2( y ~ sex + SNP, features=X[,1])$pValues

cbind(pValues, pValues2)[1,]

coef(summary(lm( y ~ sex + X[,1] )))




fit = lm( y ~ sex + sex:X[,1] )

wald.test( vcov(fit), coef(fit), 3:4)

terms = 3:4
Sigma = vcov(fit)
beta = coef(fit)

t(beta) %*% Sigma %*% beta

fit$Sigma = vcov(fit)
wald(fit, 3:4)

function (fit, terms) 
{
    if (is.null(terms) || is.na(terms) || length(terms) == 0) {
        stop("Must specify terms")
    }
    if (length(which(!(terms %in% 1:length(fit$coefficients))))) {
        stop("Element in terms is not valid or is out of range")
    }
    stat <- tcrossprod(fit$coefficients[terms], solve(fit$Sigma[terms, 
        terms])) %*% fit$coefficients[terms]
    df <- length(terms)
    res <- c(stat, df, pchisq(stat, df, lower.tail = FALSE))
    names(res) <- c("chisq", "df", "p.value")
    res <- as.data.frame(t(res))
    rownames(res) <- ""
    return(res)
}



q()
R
library(lrgpr)

set.seed(1)
n = 100
p = 500
X = matrix(sample(0:2, n*p, replace=TRUE), nrow=n)
y = rnorm(n)
sex = as.factor(sample(1:2, n, replace=TRUE))

# Fit model for all markers
pValues = glmApply( y ~ sex + sex:SNP, features=X[,1])$pValues

pValues2 = glmApply2( y ~ sex + sex:SNP, features=X[,1])$pValues

cbind(pValues, pValues2)[1,]

anova(lm( y ~ sex + sex:X[,1] ), lm( y ~ sex))



fit = lm( y ~ sex + sex:X[,1] )

crossprod(model.matrix(y ~ sex + sex:X[,1]))

beta = coef(fit)[3:4]

solve(crossprod(model.matrix(y ~ sex + sex:X[,1])))[3:4, 3:4] 

stat = t(beta) %*% solve(crossprod(model.matrix(y ~ sex + sex:X[,1])))[3:4, 3:4] %*% beta

stat = stat / var(fit$residuals)

pchisq(stat, 2, lower.tail = FALSE)




fit$Sigma = vcov(fit)
wald(fit, 3:4)


pchisq(sqrt(0.00127056), n-2, lower.tail = FALSE)


2*pt(sqrt(0.00127056), n-2, lower.tail = FALSE)

# Multivariate regression
##########################


# Generate data
n = 100
p = 500
X = matrix(sample(0:2, n*p, replace=TRUE), nrow=n)
y = rnorm(n)
sex = as.factor(sample(1:2, n, replace=TRUE))

# Fit model for all markers
pValues = glmApply( y ~ sex + sex:SNP, features=X, terms=c(3,4))$pValues
pValues2 = glmApply2( y ~ sex + sex:SNP, features=X)$pValues

cor(pValues, pValues2)


q()
R
library(lrgpr)

set.seed(1)

# Multivariate model
n = 1000
p = 1000
m = 1

Y = matrix(rnorm(n*m), nrow=n, ncol=m)
X = matrix(rnorm(n*p), nrow=n, ncol=p)

res = glmApply( Y ~ SNP, features = X, terms=2, multivariateTest=F)

res2 = glmApply2( Y ~ SNP, features = X, terms=2, multivariateTest=TRUE)

cor(as.vector(res$pValues), as.vector(res2$pValues))



system.time(glmApply2( Y[,1] ~ SNP, features = X, terms=2, multivariateTest=F))


# p-values for multivariate hypothesis test of each feature against
#       all responses are the same time
# returns the results of the Hotelling and Pillai tests
res$pValues_mv

# The multivariate test for X[,1]
res$pValues_mv[1,]

# The result is the same as the standard tests in R
fit = manova( Y ~ X[,1])

summary(fit, test="Hotelling-Lawley")
summary(fit, test="Pillai")
