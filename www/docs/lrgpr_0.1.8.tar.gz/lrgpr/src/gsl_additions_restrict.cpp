#include "gsl_additions_restrict.h"

#include <gsl/gsl_vector.h>

// C = A - B

